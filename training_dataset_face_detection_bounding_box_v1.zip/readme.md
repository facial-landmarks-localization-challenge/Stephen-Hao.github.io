The order of the coordinates is [left, top, right, bottom].

